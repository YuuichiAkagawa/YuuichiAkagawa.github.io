------------------------------------------------------------------------------

                                YM Version 2.01

                          YMODEM File Transfer Program

                                      for

                              PC-E500/1480U Series

                       Copyright (c) 1992-94 by Y.Akagawa

-----------------------------------------------------------------------------


YM 2.01 is an implementation of the YMODEM file transfer protocol.
It provides an reliable and fast possibility for file downloads and
uploads via the serial interface. Binary files can be transfered as
well as text files. Errors during a transfer are recognized by the 
protocol and automatically corrected.

YMODEM can do batch transfers of several files in a single job. 
Supported protocol variants are YMODEM(-BATCH) and YMODEM-g.

A special feature of YM 2.01 is that it supports transfer speeds
up to 19200 bit/s on the serial link of PC-E500 (also PC-1480U???).

The package ym201.lzh contains several files:
 CABLE_E.DOC   - description of serial cables (English)
 CABLE_J.DOC   - description of serial cables (Japanese)
 PATCH.BAS     - patch program
 YM            - binary of ym
 YM.UU         - self extracting, uuencoded version of ym
 YM_ENG.DOC    - this document
 YM_JPN.DOC    - the originale japanese description

"ym.uu" is a BASIC program in ASCII format created by UUSFX (E. Kako).
It contains only ASCII characters and can be downloaded to PC-E500/PC-1480
by simple LOAD or COPY commands and require no special file transfer
software on the PC-E500/PC-1480.

When the BASIC programm "ym.uu" is started on the PC-E500/PC-1480, it creates
the binary file "YM". After successful completion, "ym.uu" is no longer needed.

YM can be invoked in two different ways:

1) BASIC:

   LOADM "YM"
   CALL &BE000"-S|R[S] [-option] Filename...
  
2) Command Interpreter:
   
   YM -S|R[S] [-option] Filename...

Command line parameter of YM:

 -R[S]    receive mode, download (-RS : Force to YMODEM-single mode)
 -S       send mode, upload
 -O       Overwrite mode.(If receive file was already exists)
 -L       Rename to lower case filename.(Receive only)
 -N       No delete files, when file transfer was aborted.
 -P{A|B}  Choose the hardware flow mode at sending.(see also <About Cable>)
 -Bxxxxx  1200/2400/4800/9600/19200 (Transfer speed. Yes, 19200 is possible!)

 If you give only transfer speed or nothing, YM is send "CAN" code to opposite
 computer.
 
 "CAN": This is special character in YMODEM transfer protocol.
        If "CAN" code is receive, YMODEM transfer is abort.


Examples: (invoked via command line interpreter)
 F>YM -S ABC             ABC is uploaded to the remote computer
 F>YM -S -PB *.*         All files from Drive F: are uploaded to 
                         the remote computer (meaning of -PB???)
 F>YM -R -B9600          Files are download from the remote computer 
                         at 9600bps
 F>YM -R -O S2:          Downloaded file is directly written to S2:
                         (If receive file is already exist, they are 
                          overwrite it.)
 F>YM                    Send "CAN"code
 F>YM -B19200            Send "CAN"code  at 19200bps

About Cable:
  YMODEM-g protocol is using Hardware flow control. But cross cable is 
  various kinds exist. (reference to CABLE-E.DOC)
  
  TYPE A : (RS-CD Connection)
   *Recommended by SHARP
   *Level down converter
   
  TYPE B : (RS-CS Connection)
   *General cross cable
   *MODEM(straight cable)

  If your cable is TYPE B, specify the command line parameter "-PB",
  Otherwise additional command line parameter is unnecessary. 
  ("-PA" is default mode)

Patch:
  If you have TYPE B cable, you must specify "-PB" every time.
  When the BASIC programm "PATCH.BAT" is running on the PC-E500/PC-1480,
  default mode is change to "B".
  So, you not must specify "-PB" parameter.

  Example)
    RUN
    Drive:F
    TYPE(A/B):B
    Complete!


Errors/Diagnostics:
 File access errors:
 File can't open
 File write error

 Transmission errors:
 Block No. error (Complement error)
 Block No. error (Duplicate packet)
 Block No. error (Out of sequence)
 Sum/CRC Check error
 Retry over
 Time over


Reference materials:
 APLINKS                            N.Kon
 ISHD                               E.Kako
 PC-E500/1480U katsuyo-kenkyu       KOHGAKU-SHA
 XMODEM/YMODEM PROTOCOL REFERENCE   Chuck Forsberg


History:
�@�@V2.00 �@Initial version (YMODEM-g support)
�@�@V2.01 �@Add "-P" option
�@�@        Modify display message


Copyright and Notice:

  YM Version 2.01
    Copyright (c) 1992-94 by Y.Akagawa <yakagawa@st.rim.or.jp>

  I make no guarantee that this software will function flawlessly nor will I
 take any responsibility for damages incurred by the user either accidentally
 or intentionally through the use of this software. The software is provided
 as is.
  It is freeware and you may distribute it as such providing you keep the
 archive in original intact condition. The program may be distributed in
 freeware packages in which fees cover duplication/media costs.
  This program may not be sold commercially or privately without the permission
 of the author.


Reminder:					       
This file is no complete translation of the original documentation.
I could not decipher the original japanese documentation, but extracted
the ASCII substrings and made some guesses of the contents of documentation.

This english documentation written by 
Christoph Vogelsang (21chvo@wiwi.uni-muenster.de)
January 1999
