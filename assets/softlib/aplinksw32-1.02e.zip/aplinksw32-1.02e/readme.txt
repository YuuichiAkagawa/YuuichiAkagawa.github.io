-------------------------------------------------------------------------------
    APLINKS ( Another pocket link file server ) for Win32 Ver. 1.02

�@�@�@�@�@�@          Copyright (C) 1996-97 Y.Akagawa

�@�@�@�@�@�@          Original version copyright
           Another pocket link file server for NEW-SC Ver.1.03
 �@�@�@�@�@           Copyright (C) 1992,93 N.Kon
-------------------------------------------------------------------------------

<Introduction>
 This is the Win32 edition of the APLINKS, developed by Mr. Kon Narihito.

<Requirement>
 + IBM compatible running Windows NT 3.51 or greator, Windows 95
 + Free serial port.

<Packing list>
 aplinksw32.exe	 Main program
 aplnksRes.dll   Resource library
 delkey.exe      Registry clear program
 readme.txt      This file

<How to install>
 Copy the following files, into any directory.
�@aplinksw32.exe
�@aplnksRes.dll

<How to use>
 - Quick start -
 1. Set up the communication port.
    Choose [Setup]->[Environment...]
    select Port No. and Speed.

 2. Take in PC files.
    Choose files by the Explorer/FileManager and drop them APLINKSW32 window.

 3. Starting connection.
    Choose [File]->[Connect]

 4. Disconnection.
    You must execute following command from Pocket Computer side.
     INIT "L:D

    If you want force disconnection, choose [File]->[Disconnect].

<Bugs>
 Online help is not available.

<Contacting the Author>
  If you have any question, problem, and request, please let me by E-mail.

   yakagawa@st.rim.or.jp

  I make an effort for begin able to cope, if the time and the skill permits.

<Disclaimer>
  I make no guarantee that this software will function flawlessly nor will I 
 take any responsibility for damages incurred by the user either accidentally
 or intentionally through the use of this software. The software is provided as
 is.
 It is freeware and you may distribute it as such providing you keep the
 archive in original intact condition. The program may be distributed in
 freeware packages in which fees cover duplication/media costs. This program
 may not be sold commercially or privately without the permission of the author.
<Version history>
 Ver.1.02    1997.12.11  English version is available.
 Ver.1.01    1997.03.23  Supporting timestamp
 Ver.1.00    1996.12.11  First official release.
                         Change the icon.
                         Adding File listing button.
 Ver.0.02    1996.09.15  Beta 2 release.
                         Supporting MRU list.
                         Saveing the window size and position.
                         Choosable display fonts.
                         Overwrite confirm.
                         File listing.
                         File name upper case conversion.
 Ver.0.01    1996.05.11  Beta 1 release.
