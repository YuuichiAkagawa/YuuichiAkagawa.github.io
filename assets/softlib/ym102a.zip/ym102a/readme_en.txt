------------------------------------------------------------------------------

                                YM Version 1.02

                          YMODEM File Transfer Program

                                      for

                              PC-E500/1480U Series

                       Copyright (c) 1992-96 by Y.Akagawa

-----------------------------------------------------------------------------


YM 1.02 is an implementation of the YMODEM file transfer protocol.
It provides an reliable and fast possibility for file downloads and
uploads via the serial interface. Binary files can be transfered as
well as text files. Errors during a transfer are recognized by the 
protocol and automatically corrected.

YMODEM can do batch transfers of several files in a single job. 
Supported protocol is YMODEM(-BATCH).

A special feature of YM 1.02 is that it supports transfer speeds
up to 19200 bit/s on the serial link of PC-E500 (also PC-1480U).

The package ym102.lzh contains several files:
 YM            - binary of ym
 YM.UU         - self extracting, uuencoded version of ym
 YM_ENG.DOC    - this document
 YM_JPN.DOC    - the originale japanese description

"ym.uu" is a BASIC program in ASCII format created by UUSFX (E. Kako).
It contains only ASCII characters and can be downloaded to PC-E500/PC-1480
by simple LOAD or COPY commands and require no special file transfer
software on the PC-E500/PC-1480.

When the BASIC programm "ym.uu" is started on the PC-E500/PC-1480, it creates
the binary file "YM". After successful completion, "ym.uu" is no longer needed.

YM can be invoked in two different ways:

1) BASIC:

   LOADM "YM"
   CALL &BE000"-S|R[S] [-option] Filename...
  
2) Command Interpreter:
   
   YM -S|R[S] [-option] Filename...

Command line parameter of YM:

 -R[S]    receive mode, download (-RS : Force to YMODEM-single mode)
 -S       send mode, upload
 -O       Overwrite mode.(If receive file was already exists)
 -L       Rename to lower case filename.(Receive only)
 -N       No delete files, when file transfer was aborted.
 -Bxxxxx  1200/2400/4800/9600/19200 (Transfer speed. Yes, 19200 is possible!)

 If you give only transfer speed or nothing, YM is send "CAN" code to opposite
 computer.
 
 "CAN": This is special character in YMODEM transfer protocol.
        If "CAN" code is receive, YMODEM transfer is abort.


Examples: (invoked via command line interpreter)
 F>YM -S ABC        ABC is uploaded to the remote computer
 F>YM -S *.*        All files from Drive F: are uploaded to the remote computer
 F>YM -R -B9600     Files are download from the remote computer at 9600bps
 F>YM -R -O S2:     Downloaded file is directly written to S2:
                    (If receive file is already exist, they are overwrite it)
 F>YM               Send "CAN"code
 F>YM -B19200       Send "CAN"code  at 19200bps


Errors/Diagnostics:
 File access errors:
 File can't open
 File write error

 Transmission errors:
 Block No. error (Complement error)
 Block No. error (Duplicate packet)
 Block No. error (Out of sequence)
 Sum/CRC Check error
 Retry over
 Time over


Reference materials:
 APLINKS                            N.Kon
 ISHD                               E.Kako
 PC-E500/1480U katsuyo-kenkyu       KOHGAKU-SHA
 XMODEM/YMODEM PROTOCOL REFERENCE   Chuck Forsberg


History:
    V0.01   Preview
�@�@�@|
    V0.07

    V1.00   Official Release
    V1.01   Fix the Block No. Error
�@�@�@�@�@�@Add time out routine
�@�@V1.01a  Modify display message
    V1.01b  Modify display message
	V1.02   Reduce filename when long filename has come.
	�@�@�@�@Remove last "." when send filename has no extention


Copyright and Notice:

  YM Version 1.02
    Copyright (c) 1992-96 by Y.Akagawa <yakagawa@st.rim.or.jp>

  I make no guarantee that this software will function flawlessly nor will I
 take any responsibility for damages incurred by the user either accidentally
 or intentionally through the use of this software. The software is provided
 as is.
  It is freeware and you may distribute it as such providing you keep the
 archive in original intact condition. The program may be distributed in
 freeware packages in which fees cover duplication/media costs.
  This program may not be sold commercially or privately without the permission
 of the author.


Reminder:					       
This file is no complete translation of the original documentation.
I could not decipher the original japanese documentation, but extracted
the ASCII substrings and made some guesses of the contents of documentation.

This english documentation written by 
Christoph Vogelsang (21chvo@wiwi.uni-muenster.de)
January 1999
